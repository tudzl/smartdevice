#include <stdio.h>
#include "stdlib.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "delay.h"	 
#include "WS2811_stm32.h"
//1.25us T for one bit code

//LED IO��ʼ��

u16 ls_t; 
u8 LED_data[45][3];
u8 led_size=led_ring_size;
u8 LED_data_mode1_len;
u8 LED_data_mode1[45][3];

//ws2811 24bits data GRB, MSB first
void WS2811_pin_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE); //ʹ��GPIOG��ʱ��
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_OUT;//���
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;  //�������
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_NOPULL;  //����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;  
	//GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz; //����GPIO
	GPIO_Init(GPIOF,&GPIO_InitStructure);
	
	GPIO_SetBits(GPIOG,GPIO_Pin_9); //GPIOG9�ߵ�ƽ
}




void WS2811_SendByte(u8 dat)//??1BIT???
{
        u8 i;
        for(i=0;i<8;i++)
        {
                if(dat & 0x80) //send bit 1
                {
             Light_SDA=1;
             delay_us(1);
            Light_SDA=0;
            __nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
                }
                else                        //send bit 0
                {
            Light_SDA=1;//0
            __nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
             Light_SDA=0;
            delay_us(1);
                }
                dat <<= 1;
        }
}


void RGB_LED_Reset(void)                 
{        
    Light_SDA=0;
    delay_ms(30);
}


void WS2811_send_color(u32 color)
{
                u8 i;
	              u8 RGB_tmp=0;
                for(i=0;i<led_size;i++)
                {
									     
									      RGB_tmp=(color&0x00ff00)>>8;
												WS2811_SendByte(RGB_tmp);
									 RGB_tmp=(color&0xff0000)>>16;
												WS2811_SendByte(RGB_tmp);
												RGB_tmp=(color&0x0000ff);
												WS2811_SendByte(RGB_tmp);
									
									//
                       
									     // WS2811_SendByte(G);
									// WS2811_SendByte(R);
                       // WS2811_SendByte(B);
                }
                   RGB_LED_Reset();
}

void WS2811_send_data(u8 R,u8 G,u8 B)
{
                u8 i;
                for(i=0;i<led_size;i++)
                {
                        WS2811_SendByte(G);
                        WS2811_SendByte(R);
                        WS2811_SendByte(B);
                }
                   RGB_LED_Reset();
}


void cycle_color_function(u8 mode, u8 idx){
	u8 i;
	//mode 1: 8 LED
	//mode 24: 24 LED Ring
	if (mode ==1){
		
					 for(i=led_size;i>0;i--)
        {
               // if(idx<LED_data_mode1_len)
              //  {
                
                        WS2811_SendByte(LED_data_mode1[(idx%LED_data_mode1_len)][1]);//R
                        WS2811_SendByte(LED_data_mode1[(idx%LED_data_mode1_len)][0]);//G
                        WS2811_SendByte(LED_data_mode1[(idx%LED_data_mode1_len)][2]);//B
									idx++;
              //  }
        
        }
			
		
		
		
	}
	
		if (mode ==24){
		
					 for(i=led_ring_size;i>0;i--)
        {
               // if(idx<LED_data_mode1_len)
              //  {
                
                        WS2811_SendByte(LED_data_mode1[(idx%LED_data_mode1_len)][1]);//R
                        WS2811_SendByte(LED_data_mode1[(idx%LED_data_mode1_len)][0]);//G
                        WS2811_SendByte(LED_data_mode1[(idx%LED_data_mode1_len)][2]);//B
									idx++;
              //  }
        
        }
			
		
		
		
	}
	
	
	
	
}

void ls_mode(void)
{
        u8 i=0,ys=0,yz=0;
        for(i=led_size;i>0;i--)
        {
                if(i<=ls_t)
                {
                        if(ys<ls_t)
                        {
                          ys++;
                        }
                        else
                                ys=0;
                        WS2811_SendByte(LED_data[45-(ys%45)][1]);//R
                        WS2811_SendByte(LED_data[45-(ys%45)][0]);//G
                        WS2811_SendByte(LED_data[45-(ys%45)][2]);//B
                }
                else
                {
                        if(yz>0)
                        {
                          yz--;
                        }
                        else
                                yz=led_size-ls_t;
                        WS2811_SendByte(LED_data[yz%45][1]);
                        WS2811_SendByte(LED_data[yz%45][0]);
                        WS2811_SendByte(LED_data[yz%45][2]);
                }
        }
          RGB_LED_Reset();
}




u8 LED_data_mode1[45][3]={
	
	      {15,0,245}, //G,R,B
			  {25,0,235},
				{45,0,225},
        {55,0,215},//G,R,B
        {100,0,180},//5
        {155,0,155},
        {180,0,100},
				{215,0,55},
				{235,0,35},
        {255,0,15},//10
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},//15
        {255,0,0},
        {255,15,0},
        {235,35,0},
        {215,55,0},
        {180,100,0},
        {155,155,0},//20
        {100,180,0},//G,R,B
        {55,215,0},
        {35,235,0},
        {15,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},//30
        {0,255,15},//G,R,B
        {0,235,35},
        {0,215,55},
        {0,180,100},
        {0,155,155},
        {0,100,180},//35
        {0,55,215},
        {0,35,235},
        {0,15,255},
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255}//45
                           };
													 
u8 LED_data_mode1_len =45 ;
													 
u8 LED_data[45][3]={
        {55,0,255},//G,R,B
        {100,0,200},
        {155,0,155},
        {200,0,100},
        {255,0,55},//5
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},
        {255,0,0},//15
        {255,55,0},
        {200,100,0},
        {155,155,0},
        {100,200,0},
        {55,255,0},//20
        {0,255,0},//G,R,B
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},
        {0,255,0},//30
        {0,255,55},//G,R,B
        {0,200,100},
        {0,155,155},
        {0,100,200},
        {0,55,255},
        {0,0,255},//35
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255},
        {0,0,255}//45
                           };
													 
/*
void TIM2_IRQHandler(void)  // 1s enter
{
     if (TIM_GetITStatus(TIM2, TIM_IT_CC1) != RESET)
     {
//                        ls_mode12();
                if(++t2>=ls_speed)
                {
                        t2=0;
                        if(++ls_t>=led_size) //??!!
                                {
                                        ls_t=0;
                                }
                        }
        TIM_ClearITPendingBit(TIM2, TIM_IT_CC1 );        
     }  
}
*/
