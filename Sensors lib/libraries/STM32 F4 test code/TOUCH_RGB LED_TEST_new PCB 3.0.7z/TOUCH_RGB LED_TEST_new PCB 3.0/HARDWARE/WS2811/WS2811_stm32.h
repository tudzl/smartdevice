//WS2811 pin config

#ifndef __WS2811_stm32_H
#define __WS2811_stm32_H  

#include "sys.h"

#define Light_SDA PFout(11)
#define led_size_stripe 8  //long strip
#define led_ring_size 24  //long strip

#define LED_White       0xFFFFFF  // ??
#define LED_Black       0x000000  // ??
#define LED_Green       0x00ff00  // ??
#define LED_Red 		    0xff0000  // ??
#define LED_Blue        0x0000ff  // ??




void WS2811_SendByte(u8 dat);
void WS2811_pin_Init(void);
void RGB_LED_Reset(void);
void WS2811_send_data(u8 R,u8 G,u8 B);
void WS2811_send_color(u32 color);  //null  R  G  B
void ls_mode(void);
void cycle_color_function(u8 mode, u8 idx);



#endif

